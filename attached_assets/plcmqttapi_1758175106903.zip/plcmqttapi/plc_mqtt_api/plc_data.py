from threading import RLock
from typing import Any, Dict, Optional
from time import time
from datetime import datetime, timezone


def _utc_iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()


class PLCDataStore:
    """
    Thread-safe store for latest tag values and metadata.
    Tags are flat strings (dot-separated), e.g. 'ai.temperature'.
    """

    def __init__(self) -> None:
        self._lock = RLock()
        self._data: Dict[str, Dict[str, Any]] = {}  # tag -> { value, topic, qos, retain, ts, received_at }

    def set(self, tag: str, value: Any, *, topic: str, qos: int = 0, retain: bool = False, ts: Optional[float] = None) -> None:
        now = ts or time()
        with self._lock:
            self._data[tag] = {
                "value": value,
                "topic": topic,
                "qos": qos,
                "retain": retain,
                "ts": now,
                "received_at": _utc_iso(now),
            }

    def get(self, tag: str, include_meta: bool = False) -> Optional[Any]:
        with self._lock:
            item = self._data.get(tag)
            if item is None:
                return None
            return item if include_meta else item.get("value")

    def get_all(self, include_meta: bool = False) -> Dict[str, Any]:
        with self._lock:
            if include_meta:
                # Shallow copy is fine here; values are primitives/flat dicts
                return dict(self._data)
            else:
                return {k: v["value"] for k, v in self._data.items()}

    def tags(self) -> Dict[str, float]:
        with self._lock:
            return {k: v["ts"] for k, v in self._data.items()}