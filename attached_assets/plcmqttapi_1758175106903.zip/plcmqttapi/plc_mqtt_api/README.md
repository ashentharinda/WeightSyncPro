# S7 MQTT API (Siemens S7-1200 → MQTT → REST)

Tiny FastAPI service that subscribes to MQTT topics published by a Siemens S7-1200 (station_1) and exposes the latest values via REST.

- MQTT in
- In-memory store of the latest values (thread-safe)
- REST out:
  - GET /data → all tag values
  - GET /data/{tag} → a single tag value

Tags are flat and dot-separated (no slashes). Example:
- MQTT topic: `station_1/ai/temperature` → tag: `ai.temperature`
- MQTT topic: `station_1/json` with payload `{"pressure": 1.2, "units": "bar"}` → tags: `json.pressure` and `json.units`

## Prerequisites

- Python 3.10+
- An MQTT broker (e.g., Mosquitto)
- Your S7-1200 (station_1) publishing to MQTT topics (e.g., `station_1/#`)

> Note: S7-1200 does not natively publish MQTT without a gateway/library. Ensure your setup (TIA Portal function block, edge gateway, Node-RED, etc.) publishes to the broker.

## Setup

```bash
git clone <this-repo> plc_mqtt_api
cd plc_mqtt_api
python -m venv .venv
. .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt"# plc_mqtt_api" 
