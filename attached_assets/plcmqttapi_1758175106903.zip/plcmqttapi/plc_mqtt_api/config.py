import os
import uuid

# -----------------------------
# PLC / Station Metadata
# -----------------------------
PLC_STATION = os.getenv("PLC_STATION", "station_1")
PLC_IP = os.getenv("PLC_IP", "192.168.1.130")

# -----------------------------
# MQTT Broker Configuration
# -----------------------------
# MQTT Broker Configuration - REQUIRED environment variables
MQTT_BROKER_HOST = os.getenv("MQTT_BROKER_HOST")  # REQUIRED: MQTT broker hostname
MQTT_USERNAME = os.getenv("MQTT_USERNAME")        # REQUIRED: MQTT username  
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD")        # REQUIRED: MQTT password

# TLS Configuration
MQTT_TLS = os.getenv("MQTT_TLS", "true").lower() in {"1", "true", "yes"}

# Port logic: Use 8883 for TLS, 1883 for non-TLS
default_port = "8883" if MQTT_TLS else "1883"
MQTT_BROKER_PORT = int(os.getenv("MQTT_BROKER_PORT", default_port))
MQTT_QOS = int(os.getenv("MQTT_QOS", "0"))

# Topics to subscribe to
MQTT_TOPICS_RAW = os.getenv("MQTT_TOPICS", f"{PLC_STATION}/#")
MQTT_TOPICS = [t.strip() for t in MQTT_TOPICS_RAW.split(",") if t.strip()]

# MQTT client ID (unique)
MQTT_CLIENT_ID = os.getenv("MQTT_CLIENT_ID", f"s7-mqtt-api-{uuid.uuid4().hex[:8]}")

# Additional TLS Settings
MQTT_TLS_INSECURE = os.getenv("MQTT_TLS_INSECURE", "false").lower() in {"1", "true", "yes"}
MQTT_TLS_CA_CERTS = os.getenv("MQTT_TLS_CA_CERTS", "") or None
MQTT_TLS_CERTFILE = os.getenv("MQTT_TLS_CERTFILE", "") or None
MQTT_TLS_KEYFILE = os.getenv("MQTT_TLS_KEYFILE", "") or None

# -----------------------------
# Logging
# -----------------------------
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
