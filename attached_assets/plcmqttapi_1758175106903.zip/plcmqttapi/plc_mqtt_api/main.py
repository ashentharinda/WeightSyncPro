import logging
from typing import Any, Dict, Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse
from starlette.middleware.cors import CORSMiddleware

from plc_data import PLCDataStore
from mqtt_client import MQTTClient
import config


# Logging
logging.basicConfig(level=config.LOG_LEVEL)
logger = logging.getLogger("api")

app = FastAPI(title="S7 MQTT API", version="1.0.0")

# Optional CORS (open by default; adjust for production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Shared state
store = PLCDataStore()
mqtt_client = MQTTClient(store=store)


@app.on_event("startup")
def on_startup():
    if config.MQTT_BROKER_HOST:
        try:
            mqtt_client.connect_and_start()
            logger.info("API started. Subscribing to topics: %s", config.MQTT_TOPICS)
        except Exception as e:
            logger.warning("MQTT client failed to start: %s", e)
            logger.info("API will continue without MQTT connectivity")
    else:
        logger.info("No MQTT broker configured. API starting without MQTT connectivity.")


@app.on_event("shutdown")
def on_shutdown():
    try:
        mqtt_client.stop()
    except Exception as e:
        logger.warning("Error during MQTT client shutdown: %s", e)
    logger.info("API shutdown complete.")


@app.get("/health")
def health() -> Dict[str, Any]:
    return {
        "status": "ok",
        "station": config.PLC_STATION,
        "broker": f"{config.MQTT_BROKER_HOST}:{config.MQTT_BROKER_PORT}",
        "topics": config.MQTT_TOPICS,
    }


@app.get("/data")
def get_all_data(include_meta: bool = Query(default=False, description="Include metadata for each tag")) -> Dict[str, Any]:
    return store.get_all(include_meta=include_meta)


@app.get("/data/{tag}")
def get_tag(tag: str, include_meta: bool = Query(default=False, description="Include metadata")) -> Any:
    value = store.get(tag, include_meta=include_meta)
    if value is None:
        raise HTTPException(status_code=404, detail=f"Tag not found: {tag}")
    return value


# If you want a quick test run: uvicorn main:app --reload
if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)