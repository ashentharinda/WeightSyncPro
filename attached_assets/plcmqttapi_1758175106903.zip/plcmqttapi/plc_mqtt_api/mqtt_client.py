import json
import logging
from typing import Any, Dict
import ssl

import paho.mqtt.client as mqtt

from plc_data import PLCDataStore
import config


logger = logging.getLogger("mqtt")
logger.setLevel(config.LOG_LEVEL)


def _after_station(topic: str, station: str) -> str:
    """
    If topic starts with '{station}/', return the part after it.
    Else return the whole topic.
    """
    prefix = f"{station}/"
    if topic.startswith(prefix):
        return topic[len(prefix):]
    return topic


def _normalize_tag_from_topic(topic: str) -> str:
    """
    Convert topic after station prefix to a dot-separated tag.
    station_1/ai/temperature -> ai.temperature
    """
    sub = _after_station(topic, config.PLC_STATION)
    return sub.replace("/", ".") if sub else topic.replace("/", ".")


def _coerce_scalar(s: str) -> Any:
    """
    Try to coerce string to number/bool/null; fallback to original string.
    """
    s_strip = s.strip()
    # Try JSON for booleans/null/numbers
    try:
        val = json.loads(s_strip)
        # Only accept if it is a primitive, not dict/list
        if not isinstance(val, (dict, list)):
            return val
    except Exception:
        pass
    # Try float
    try:
        if "." in s_strip or "e" in s_strip.lower():
            return float(s_strip)
        return int(s_strip)
    except Exception:
        return s


class MQTTClient:
    def __init__(self, store: PLCDataStore) -> None:
        self.store = store
        self.client = mqtt.Client(client_id=config.MQTT_CLIENT_ID, clean_session=True)
        if config.MQTT_USERNAME:
            self.client.username_pw_set(config.MQTT_USERNAME, config.MQTT_PASSWORD)

        if config.MQTT_TLS:
            tls_kwargs: Dict[str, Any] = {}
            if config.MQTT_TLS_CA_CERTS:
                tls_kwargs["ca_certs"] = config.MQTT_TLS_CA_CERTS
            if config.MQTT_TLS_CERTFILE:
                tls_kwargs["certfile"] = config.MQTT_TLS_CERTFILE
            if config.MQTT_TLS_KEYFILE:
                tls_kwargs["keyfile"] = config.MQTT_TLS_KEYFILE

            self.client.tls_set(**tls_kwargs)  # type: ignore[arg-type]
            if config.MQTT_TLS_INSECURE:
                self.client.tls_insecure_set(True)

        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        self.client.on_disconnect = self._on_disconnect

    def connect_and_start(self) -> None:
        logger.info(
            "Connecting to MQTT broker %s:%s as %s; topics=%s",
            config.MQTT_BROKER_HOST,
            config.MQTT_BROKER_PORT,
            config.MQTT_CLIENT_ID,
            config.MQTT_TOPICS,
        )
        # 60s keepalive
        self.client.connect(config.MQTT_BROKER_HOST, config.MQTT_BROKER_PORT, 60)
        self.client.loop_start()

    def stop(self) -> None:
        try:
            self.client.loop_stop()
        finally:
            try:
                self.client.disconnect()
            except Exception:
                pass

    # Callbacks (paho-mqtt v1.x signatures)
    def _on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            logger.info("MQTT connected (rc=%s). Subscribing...", rc)
            subs = [(t, config.MQTT_QOS) for t in config.MQTT_TOPICS]
            result, mid = client.subscribe(subs)
            if result != mqtt.MQTT_ERR_SUCCESS:
                logger.error("Subscribe failed: %s", result)
        else:
            logger.error("MQTT connection failed (rc=%s)", rc)

    def _on_disconnect(self, client, userdata, rc):
        if rc != 0:
            logger.warning("Unexpected MQTT disconnect (rc=%s). Will retry...", rc)
        else:
            logger.info("MQTT disconnected.")

    def _on_message(self, client, userdata, msg: mqtt.MQTTMessage):
        try:
            payload_bytes = msg.payload or b""
            payload_str = payload_bytes.decode("utf-8", errors="replace")
            tag_base = _normalize_tag_from_topic(msg.topic)

            # Try JSON first
            value: Any
            try:
                parsed = json.loads(payload_str)
                if isinstance(parsed, dict):
                    # Flatten dict into multiple tags under the same base
                    for k, v in parsed.items():
                        tag = f"{tag_base}.{k}"
                        self.store.set(
                            tag,
                            v,
                            topic=msg.topic,
                            qos=msg.qos,
                            retain=bool(msg.retain),
                        )
                    return
                else:
                    value = parsed
            except Exception:
                # Not JSON -> coerce primitive or keep string
                value = _coerce_scalar(payload_str)

            # Store scalar/list directly under the base tag
            self.store.set(
                tag_base,
                value,
                topic=msg.topic,
                qos=msg.qos,
                retain=bool(msg.retain),
            )
        except Exception as e:
            logger.exception("Error processing MQTT message: %s", e)