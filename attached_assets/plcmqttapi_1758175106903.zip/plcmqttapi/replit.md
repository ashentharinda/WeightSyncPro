# PLC MQTT API

## Overview

This is a lightweight FastAPI service that acts as a bridge between Siemens S7-1200 PLCs and REST APIs. The system subscribes to MQTT topics published by industrial controllers and exposes the latest sensor/control values via REST endpoints. It features real-time data ingestion from MQTT, thread-safe in-memory storage, and simple REST API access to PLC data.

The architecture includes a complementary serial data dashboard for direct serial communication with industrial devices, providing WebSocket-based real-time data streaming to web clients.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Application Architecture
- **FastAPI Framework**: Main web framework providing REST API endpoints and automatic OpenAPI documentation
- **Asynchronous Design**: Uses FastAPI's async capabilities for handling multiple concurrent requests
- **MQTT Integration**: Paho MQTT client for subscribing to industrial device topics
- **Thread-Safe Data Store**: Custom PLCDataStore class using RLock for concurrent access protection

### Data Flow Architecture
- **MQTT Subscriber**: Listens to configurable MQTT topics (default: `station_1/#`)
- **Topic Normalization**: Converts MQTT topics to dot-separated tags (e.g., `station_1/ai/temperature` → `ai.temperature`)
- **JSON Payload Handling**: Automatically flattens JSON payloads into individual tags
- **Type Coercion**: Intelligent conversion of string values to appropriate data types (numbers, booleans)

### Configuration Management
- **Environment-Based**: All configuration through environment variables
- **TLS Support**: Configurable MQTT TLS encryption with certificate management
- **Flexible Deployment**: Supports various MQTT broker configurations and authentication methods

### REST API Design
- **GET /data**: Returns all current tag values
- **GET /data/{tag}**: Returns specific tag value
- **Optional Metadata**: Include timestamps, QoS, and retention flags
- **CORS Enabled**: Cross-origin requests supported for web client integration

### Serial Communication Module
- **Separate Service**: Independent FastAPI application for direct serial device communication
- **WebSocket Streaming**: Real-time data push to web clients
- **Dashboard Interface**: HTML/JavaScript frontend for monitoring serial data
- **Configurable Ports**: Support for various serial port configurations

### Error Handling Strategy
- **Graceful Degradation**: API continues operating without MQTT connectivity
- **Connection Recovery**: MQTT client handles reconnection scenarios
- **Comprehensive Logging**: Configurable log levels for debugging and monitoring

## External Dependencies

### MQTT Infrastructure
- **MQTT Broker**: Requires external MQTT broker (Mosquitto, AWS IoT, etc.)
- **Authentication**: Username/password authentication with optional TLS
- **Topic Structure**: Expects hierarchical topic naming from PLC stations

### Industrial Hardware Integration
- **Siemens S7-1200 PLC**: Primary target for MQTT data publication
- **Gateway Requirements**: PLC requires MQTT gateway/library (TIA Portal function blocks, Node-RED, etc.)
- **Serial Devices**: Direct serial communication for legacy industrial equipment

### Python Runtime Dependencies
- **FastAPI**: Web framework and API documentation
- **Uvicorn**: ASGI server for production deployment
- **Paho MQTT**: MQTT client library for broker communication
- **PySerial**: Serial port communication library

### Network Configuration
- **Port Requirements**: Default MQTT ports 1883 (non-TLS) or 8883 (TLS)
- **Firewall Considerations**: Inbound access required for REST API endpoints
- **Certificate Management**: Optional TLS certificate configuration for secure MQTT