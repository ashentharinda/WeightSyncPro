# server.py
import serial
import asyncio
import uvicorn
from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware

# Configure serial port (update according to your device)
SERIAL_PORT = "COM3"   # e.g., COM3 on Windows, /dev/ttyUSB0 on Linux
BAUD_RATE = 9600

app = FastAPI()

# Allow frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

clients = []

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    clients.append(websocket)
    try:
        while True:
            await asyncio.sleep(1)
    except:
        clients.remove(websocket)


async def serial_reader():
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
    while True:
        line = ser.readline().decode("utf-8").strip()
        if line:
            print(f"Serial Data: {line}")
            # send data to all connected clients
            living_clients = []
            for ws in clients:
                try:
                    await ws.send_text(line)
                    living_clients.append(ws)
                except:
                    pass
            clients[:] = living_clients
        await asyncio.sleep(0.1)


@app.on_event("startup")
async def startup_event():
    asyncio.create_task(serial_reader())


if __name__ == "__main__":
    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=True)
